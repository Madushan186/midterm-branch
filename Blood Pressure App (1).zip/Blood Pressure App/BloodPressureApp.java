import java.util.ArrayList;
import java.util.Scanner;

/**
* Main class for blood pressure monitor application
*/
public class BloodPressureApp {

  private ArrayList<BloodPressure> bpRecords;

  public BloodPressureApp() {
    bpRecords = new ArrayList<>(); 
  }

  public static void main(String[] args) {
    BloodPressureApp app = new BloodPressureApp();
    app.displayMenu();
  }

  /**
  * Displays menu and handles user input
  */
  public void displayMenu() {
    Scanner sc = new Scanner(System.in);
    int choice;
    
    do {
      System.out.println("\nBlood Pressure Monitor");
      System.out.println("1. Create Record");
      System.out.println("2. View All Records"); 
      System.out.println("3. View Record");
      System.out.println("4. Delete All Records");
      System.out.println("5. Exit");
      System.out.print("Enter choice: ");
      choice = sc.nextInt();
      
      switch(choice) {
        case 1: 
          create();
          break;
        case 2:
          index();
          break;
        case 3:
          view();
          break;
        case 4:
          delete();
          break;
        case 5:
          exit();
          break;
        default:
          System.out.println("Invalid choice");
      }
    } while(choice != 5);
    
    sc.close();
  }
  
  /**
  * Creates a new blood pressure record
  */
  public void create() {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter user id: ");
    int id = sc.nextInt();  
    System.out.print("Enter name: ");
    String name = sc.next();
    System.out.print("Enter year of birth: ");
    int yob = sc.nextInt();
    System.out.print("Enter systolic reading: ");
    int systolic = sc.nextInt();
    System.out.print("Enter diastolic reading: ");  
    int diastolic = sc.nextInt();
    
    BloodPressure bp = new BloodPressure(id, name, yob, systolic, diastolic);
    bpRecords.add(bp);
    System.out.println("Record added successfully!");
  }

  /**
  * Displays all blood pressure records
  */
  public void index() {
    System.out.println("\n** Blood Pressure Records **");
    for(BloodPressure bp : bpRecords) {
      bp.display(); 
    }
  }
  
  /**
  * Displays blood pressure data for given id
  */

public void view() {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter user id: ");
    int id = sc.nextInt();

    for (BloodPressure bp : bpRecords) {
        if (bp.getId() == id) {
            bp.display();
            String category = bp.calculate();
            System.out.println("Blood Pressure Category: " + category);
            return;
        }
    }

    System.out.println("Record not found for id " + id);
}



  /**
  * Deletes all records
  */
  public void delete() {
    bpRecords.clear();
    System.out.println("All records deleted!");
  }

  /**
  * Exits application  
  */
  public void exit() {
    System.out.println("Exiting application...");
    System.exit(0);
  }
}

/**
* Represents blood pressure record for a user
*/ 
class BloodPressure {

  private int id;
  private String name;
  private int yob;
  private int systolic;
  private int diastolic;

 public BloodPressure(int id, String name, int yob, int systolic, int diastolic) {
    this.id = id;
    this.name = name;
    this.yob = yob;
    this.systolic = systolic;
    this.diastolic = diastolic;
  }

  // Getters and setters

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getYob() {
    return yob;
  }

  public void setYob(int yob) {
    this.yob = yob;
  }

  public int getSystolic() {
    return systolic;
  }

  public void setSystolic(int systolic) {
    this.systolic = systolic;
  }

  public int getDiastolic() {
    return diastolic;
  }

  public void setDiastolic(int diastolic) {
    this.diastolic = diastolic;
  }
  
  public String calculate() {

  if(systolic < 120 && diastolic < 80) {
    return "Normal";
  }

  if(systolic >=120 && systolic <= 129 && diastolic < 80) {
    return "Elevated"; 
  }

  if(systolic >= 130 && systolic <= 139 || diastolic >= 80 && diastolic <= 89) {
    return "Hypertension Stage 1";
  }

  if(systolic >= 140 || diastolic >= 90) { 
    return "Hypertension Stage 2";
  }

  if(systolic > 180 || diastolic > 120) {
    return "Hypertensive Crisis";
  }

  return "";
}

  /**
  * Displays blood pressure data
  */
public void display() {
    String category = calculate();
    System.out.println(
        "Id: " + id +
        ", Name: " + name +
        ", YOB: " + yob +
        ", BP: " + systolic + "/" + diastolic +
        ", Category: " + category
    );
}
}